import RatePage from "@/components/ui/RatePage"; // Adjust path if needed

const RatePageRoute = () => {
  return <RatePage />;
};

export default RatePageRoute;
